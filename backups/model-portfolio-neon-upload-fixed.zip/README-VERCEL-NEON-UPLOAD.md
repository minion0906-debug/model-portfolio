# Vercel + Neon upload fix (no S3)

Vercel filesystem is ephemeral, so local uploads under public/uploads disappear or fail after deployment. This upgrade stores uploaded image/video bytes in Neon Postgres using a MediaBlob table and serves them through /api/media/blob/:id.

Required environment:
- DATABASE_URL=your Neon pooled connection string
- DIRECT_URL=your Neon direct connection string (if Prisma migrations require it)

After deploying:
1. Run Prisma migration:
   npx prisma migrate deploy
2. Regenerate client:
   npx prisma generate

No S3 bucket or object storage variables are required.
