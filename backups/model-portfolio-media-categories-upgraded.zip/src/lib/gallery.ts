import { unstable_cache } from "next/cache";
import { prisma, logDatabaseError, withDatabaseRetry } from "@/lib/prisma";

export type PublicGalleryImage = {
  id: string;
  src: string;
  title: string;
  tag: string;
  priceCents: number;
  currency: string;
  category: string;
  orientation: string;
};

const loadPublishedGalleryImages = unstable_cache(
  async (): Promise<PublicGalleryImage[]> => {
    try {
      const media = await withDatabaseRetry(() => prisma.media.findMany({
        where: { type: "IMAGE", published: true },
        orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
        select: {
          id: true,
          url: true,
          thumbnail: true,
          title: true,
          priceCents: true,
          currency: true,
          category: true,
          orientation: true,
          tags: {
            select: { tag: { select: { name: true } } },
            take: 1,
          },
        },
      }));

      return media.map((item) => ({
        id: item.id,
        src: item.thumbnail || item.url,
        title: item.title || "Untitled",
        tag: item.tags[0]?.tag.name || "Portfolio",
        priceCents: item.priceCents,
        currency: item.currency,
        category: item.category || item.tags[0]?.tag.name || "Portfolio",
        orientation: item.orientation || "unknown",
      }));
    } catch (error) {
      logDatabaseError("gallery", error);
      return [];
    }
  },
  ["public-gallery", "v2"],
  { revalidate: 60, tags: ["public-portfolio"] },
);

export function getPublishedGalleryImages() {
  return loadPublishedGalleryImages();
}
